import React from 'react';
import { InputField } from '../lib/index';

const App = () => (
  <div>
    <InputField icon="user" />
  </div>
);

export default App;
