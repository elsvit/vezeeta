# Changelog

## 1.3.0

- Refactor all components to match airbnb guides
- Fix combo-box issue
- Improve input's field error experience
- Add onLogoClick prop in header

## 1.0.0

- Add all components
- Create documentation for external usage components

## 0.0.2

- Setup webpack.config.prod.js
- Customize package.json
