# Changelog

# 1.1.0

- Adapt Airbnb rules

## 1.0.0

- Setup webpack.config.prod.js
- Customize package.json