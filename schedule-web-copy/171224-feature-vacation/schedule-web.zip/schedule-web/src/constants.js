export const scheduleTypes = {
  onSchedule: 1,
  fifo: 2
};

export const genderTypes = {
  male: 0,
  female: 1
};
