import React, { Component } from 'react';
// import InfiniteCalendar from 'react-infinite-calendar';
// import 'react-infinite-calendar/styles.css';

// import { DateRangePicker } from 'react-dates';
// import 'react-dates/lib/css/_datepicker.css';

import './Calendar.scss';

class Calendar extends Component {
  render() {
    return <div id="Calendar" />;
  }
}

export default Calendar;
